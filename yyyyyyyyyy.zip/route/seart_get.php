<?php
$searchTerm = $_GET['search'] ?? '';

if ($searchTerm) {
    $activities = searchActivities($searchTerm);
} else {
    $activities = getActivities();
}

if (count($activities) > 0) {
    foreach ($activities as $activity) {
        header("Location: /data?id=" . $activity['aid']);
        exit(); 
    }
} else {
    echo "<p>ไม่พบกิจกรรมที่ตรงกับคำค้นหา</p>";
}
