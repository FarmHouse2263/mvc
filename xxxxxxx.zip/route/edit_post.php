<?php

// ตรวจสอบการส่งข้อมูลจากฟอร์ม
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $image = trim($_POST['image'] ?? '');

    // ตรวจสอบข้อมูลที่ได้รับ
    if (empty($name) || empty($description) || empty($start_date) || empty($end_date) || empty($image)) {
        $_SESSION['error'] = "กรุณากรอกข้อมูลให้ครบทุกช่อง";
        header("Location: /edit?id=" . $_POST['id']); // กลับไปที่หน้า edit
        exit;
    }

    // เรียกใช้ฟังก์ชันใน Model เพื่ออัพเดทข้อมูล
    if (updateActivity($_POST['id'], $name, $description, $start_date, $end_date, $image)) {
        $_SESSION['success'] = "แก้ไขกิจกรรมสำเร็จ!";
        header("Location: /Choose_activity");
        exit;
    } else {
        $_SESSION['error'] = "เกิดข้อผิดพลาดในการแก้ไขกิจกรรม";
        header("Location: /activities");
        exit;
    }
}




?>
